public class Card {

    private int id;
    private int sale;

    public int getSale() {
        return sale;
    }
}
